# Planet DDS Design System

A design system for Planet DDS products, forked from **Untitled UI** and adapted with Planet DDS blue as the brand color. Built by the `@planetdds/ui` React library and `@planetdds/tokens` token package — this folder is a design-first companion containing CSS variables, preview cards, and UI kits you can lift into mockups, decks, and throwaway prototypes.

## Products covered
Per `@planetdds/ui`'s own JSDoc, this library supports:

- **Planet Artemis** — practice management / analytics SaaS for dental practices
- **DentalOS** — dental office operating system
- **Cloud9** — practice management platform
- **Apteryx** — dental imaging
- Plus any other Planet DDS product surface

All share the same base component library and tokens.

## Sources
- **Codebase (read-only mount):** `@planetdds/` — the packages `@planetdds/ui` (components, styles) and `@planetdds/tokens` (Style Dictionary tokens)
- Token definitions: `@planetdds/tokens/tokens.json`
- Component styles: `@planetdds/ui/src/styles/{theme.css,typography.css,globals.css}`
- Component source: `@planetdds/ui/src/components/{base,application,foundations,marketing,shared-assets}`
- Icons: `@untitledui/icons` + `lucide-react` (peer deps of `@planetdds/ui`)
- Tailwind v3 + `tailwind-merge` + `react-aria-components`

> Reader note: the codebase is mounted locally and not shipped with this design system. If you have access, explore it via the `@planetdds/` mount.

---

## Index

| File / Folder | What it is |
|---|---|
| `README.md` | This file — brand, content, and visual guidelines |
| `SKILL.md` | Agent Skill entry point — cross-compatible with Claude Code skills |
| `colors_and_type.css` | All color + type + spacing + radius + shadow CSS variables |
| `preview/` | Small HTML cards that populate the Design System tab |
| `ui_kits/artemis/` | UI kit for Planet Artemis (practice management app) |
| `ui_kits/marketing/` | UI kit for the marketing / product-page surface |
| `assets/` | Logos, payment icons, iPhone mockup image, etc. |
| `fonts/` | (Inter and JetBrains Mono are loaded via Google Fonts — see caveat) |

---

## Brand identity

Planet DDS is a B2B dental-SaaS company. The design language is **calm, confident, utility-first** — the kind of tone a clinical admin tool needs. No playful gradients, no emoji, no whimsical illustrations. Clear hierarchy, plenty of whitespace, skeuomorphic button treatments for tactility, and a single-hue blue accent (`#0074E8`) doing most of the expressive work.

The logo slot in this fork still uses the Untitled UI minimal mark (a rounded-square with a purple gradient disc) — **⚠️ see caveat below.**

---

## CONTENT FUNDAMENTALS

### Voice & tone
- **Clear, direct, professional.** This is a product used by dental-office admins, doctors, and billing staff. Ambiguity costs real money.
- **Second person, active voice.** "You can invite a teammate" — not "Teammates may be invited."
- **Calm, never urgent.** Alerts describe what happened factually; CTAs lead with verbs.
- **Noun-first labels, sentence-case buttons.** Table headers and nav items are Title Case ("Patients", "Insurance Claims"); buttons are Sentence case ("Add patient", "Send reminder", "Upgrade plan").

### Casing
- **Sentence case** for buttons, menu items, dialog titles, form labels. ("Create account", "Forgot password?", "Email address")
- **Title Case** for navigation, page titles, section headers. ("Dashboard", "Insurance Claims", "Team Members")
- **ALL CAPS** reserved for micro-labels ("NEW", tag pills) and tracking-wide section eyebrows — sparingly.

### Punctuation
- **No terminal periods** on UI micro-copy (buttons, labels, tooltips, empty-state titles).
- **Periods on sentences** in body paragraphs, alert descriptions, form hint text.
- Question marks OK on prompts ("Delete this patient record?").
- Oxford comma: yes.

### Pronouns
- **"You"** addressing the user. Never "the user", never "one".
- **"We"** only for the product team voice on marketing pages / transactional email. In-app, prefer agentless ("Your invoice was sent") over "We sent your invoice".

### Emoji / exclamation marks
- **No emoji.** Anywhere. This is a clinical/financial tool.
- **No exclamation marks** in the UI. In empty states, keep it flat: "No results found" — not "No results found!"
- Marketing email is the only place a mild "Welcome to Planet DDS" subject line is acceptable — still no emoji.

### Examples (from nearby dental-SaaS patterns — adapt, don't copy)
- ✅ "Add patient"
- ✅ "No appointments scheduled for today"
- ✅ "Your changes were saved"
- ✅ "Invite a team member"
- ❌ "Let's get you started! 🎉"
- ❌ "Oops, something went wrong."
- ❌ "Hit the button below to continue!"

### Microcopy recipes
- **Empty state title:** noun phrase, no period. *"No patients yet"*
- **Empty state body:** one short sentence + primary action. *"Add your first patient to start tracking visits."*
- **Error:** start with what happened, then what to do. *"We couldn't send that email. Check the address and try again."*
- **Success toast:** passive-voice confirmation. *"Appointment rescheduled."*

---

## VISUAL FOUNDATIONS

### Color
- **Single-hue brand:** Planet DDS blue, `#0074E8` at the 500 step. Brand 600 (`#0069DC`) is the most-used solid (button fill, primary links); 50/100 are the tint backgrounds; 800 is reserved for dark "brand section" backgrounds (footer, CTA bands).
- **Neutrals:** warm-cool hybrid gray scale (Untitled UI's default gray — 25→950). `gray-900` for titles, `gray-700` for body, `gray-600` for supporting, `gray-500` for placeholders.
- **Semantics:** red (Error), amber (Warning), green (Success) — each with 25→700 steps. Used for badges, toasts, inline validation. No info-blue alert color — info uses the brand.
- **Accent palette on hand for charts & tags:** Teal, Cyan, Blue light, Indigo, Violet, Purple, Fuchsia, Pink, Rose, Orange, Orange dark, Yellow, Green, Moss. These are *for data viz and tag chips only* — not for UI chrome.
- **Backgrounds are white or gray-50.** The system does not use gradient page backgrounds. Dark "brand sections" (footers, CTAs) use `brand-800` or `gray-950`.

### Typography
- **Inter** for both display and body (`--font-display` and `--font-body` both resolve to Inter).
- **JetBrains Mono** for code (the tokens spec just said "Roboto Mono" as fallback; JetBrains Mono is our CDN choice — **see caveat**).
- **Display sizes** go from `display-xs` 24px up to `display-2xl` 72px, with progressive negative letter-spacing (-0.72 → -1.44 px) at the larger sizes.
- **Body** is 16px / 24px line-height at `text-md`. Never go below 14px (`text-sm`) in app chrome; never below 12px (`text-xs`) anywhere.
- **Weights used:** 400 regular, 500 medium, 600 semibold, 700 bold. Headings are 600. Buttons are 600. Body is 400.

### Spacing & rhythm
- 4-px base unit. The scale jumps 2 → 4 → 6 → 8 → 12 → 16 → 20 → 24 → 32 → 40 → 48 → 64 → 80 → 96.
- Card padding defaults to 24px (`space-3xl`). Section padding vertically is 64–96px on web, 48–64px on mobile.
- Form field vertical rhythm: 6px gap label-to-input, 24–32px between fields.

### Radius
- **Default radius is 8px** (`--radius-md`) — inputs, buttons, cards.
- Small chips/tags use 6px (`--radius-sm`) or `full` pill.
- Dialogs and large feature cards use 12–16px.
- Full-round (`9999px`) on avatars, toggle knobs, status dots.

### Shadow & elevation
Five public steps — `xs`, `sm`, `md`, `lg`, `xl`, `2xl`, `3xl`. Shadows are **cool-gray** (`rgba(10,13,18, ...)`) — never pure black.
- `shadow-xs` — input fields, inline chips
- `shadow-sm` — hovered cards, dropdown triggers
- `shadow-lg` — popovers, floating menus
- `shadow-xl` / `2xl` — modals, toasts
- **Signature move:** `shadow-xs-skeuomorphic` — an `xs` drop + an inset 1px ring + a 2px inset darker line at the bottom. Gives buttons a slightly tactile, pressed-in look. Every primary/secondary button in this system uses it.

### Borders
- 1px solid is the default border weight.
- `border-primary` (`gray-300`) for form controls.
- `border-secondary` (`gray-200`) for card separators, dividers.
- `border-brand` (`brand-500`) for focused/selected states.

### Buttons
Seven color variants × four sizes (sm, md, lg, xl). All share:
- `rounded-lg` (8–10 px) corners
- 600 weight text
- `shadow-xs-skeuomorphic` for filled variants
- `transition duration-100 ease-linear` on all hover changes
- `before:absolute before:inset-px before:border-2 before:border-white/15 before:mask-b-from-0%` on the primary variant — a **top-edge white highlight** that fades downward, giving a glossy skeuomorphic lift.

Variants:
1. **primary** — `bg-brand-solid` (brand-600), white text
2. **secondary** — white bg, gray text, gray ring
3. **tertiary** — no bg, gray text (ghost)
4. **link-gray / link-color / link-destructive** — text only
5. **primary-destructive / secondary-destructive / tertiary-destructive** — error equivalents

### Hover / press / focus
- **Hover:** one step darker bg (e.g. brand-600 → brand-700 on primary; gray-50 overlay on secondary).
- **Press / active:** the skeuomorphic inner shadow is already there; no extra shrink transform — the system relies on the highlight/shadow to convey depth.
- **Focus:** `outline-2 outline-offset-2` in the brand (or error) color. Always visible on keyboard nav.
- **Disabled:** `bg-gray-100` + `text-gray-400` + `shadow-xs` (the skeuomorphic ring drops to subtle).
- **Opacity** is *not* used to convey state — everything desaturates to explicit disabled tokens instead.

### Transparency & blur
- Almost never used. The system is opaque.
- Exception: modal overlays use a `rgba(10,13,18, 0.4)` backdrop.
- Tooltip has a subtle opacity on long text but otherwise cards are solid white.

### Cards
- White background (`bg-primary`), `border-secondary` 1px, `radius-xl` (12px), `shadow-xs` at rest.
- Hover lifts to `shadow-md`.
- Internal padding 24px.
- Card *headers* use a subtle bottom divider (`border-secondary`).

### Images & imagery
- **Product screenshots** live on a light gray (`gray-50`) background with generous margin, usually inside an iPhone mockup frame or a browser chrome.
- **Photography:** clinical, warm-neutral — shots of dental offices, staff, patient interactions. No heavy filters. No black-and-white.
- **No hand-drawn illustrations.** If illustration is needed, use the Untitled UI "Box" line-illustration in `shared-assets/illustrations/box` — a simple wireframe-style geometric piece.
- **Background patterns:** `Circle`, `Grid`, `GridCheck`, `Square` — thin-stroke radial patterns at ~5% opacity, used as subtle page-section accents.

### Animation
- **Duration:** 100ms for interactions (buttons, hovers), 150–200ms for menus/tooltips, 300ms for modal enter/exit.
- **Easing:** `ease-linear` on micro hovers, `ease-out` for entering elements, `ease-in` for exiting.
- **Two named keyframes exist:** `marquee` (60s linear infinite — logo cloud scrollers) and `caret-blink` (1s — text input cursor).
- **No bounce, no spring.** The system uses Framer Motion under the hood but its personality is restrained.
- **No scroll-triggered reveals** in-app; marketing pages may use `react-intersection-observer` to fade content in once.

### Layout
- Max container width: **1280px** (`--max-width-container`).
- Breakpoints: `xxs 320`, `xs 600`, `sm 640`, `md 768`, `lg 1024`, `xl 1280`, `2xl 1536`.
- Fixed elements: top app-bar (64px), left sidebar (280px expanded / 72px slim). Sidebar can be slim or dual-tier.

### Iconography vibe (see next section for the full rules)
- Outline icons, 1.5px stroke, 20–24px target size.

---

## ICONOGRAPHY

The codebase uses two icon sets as runtime peer deps:

1. **`@untitledui/icons`** — the primary set. Line icons, 1.5px stroke, 24×24 viewbox. Used everywhere in-app.
2. **`lucide-react`** — a backup set with the same aesthetic (1.5px stroke line icons). Occasionally used where Untitled UI doesn't have an icon.

Because those packages aren't available as static CDN URLs in the quantity we'd need for this design system, **we substitute Lucide from CDN** (`https://unpkg.com/lucide@latest`) in mockups and slide decks. The stroke weight (1.5–2px) and geometry are visually ~95% the same — flag any customers where the brand team wants exact Untitled UI glyphs. **⚠️ See caveat.**

### Rules
- **Stroke weight:** 1.5px (default) or 2px for 16px-and-smaller icons.
- **Size:** 16px (inline with text-sm), 20px (default, inline with buttons), 24px (section headers), 32px+ for featured icons.
- **Color:** inherits from `currentColor` via Tailwind `text-fg-quaternary` / `text-fg-brand-primary` utilities. Never hard-coded.
- **Featured icons:** when an icon is the hero of a card/empty state, wrap in a square (`FeaturedIcon` component) with brand-50 bg, brand-600 icon, rounded-md. Several sizes: sm 32, md 40, lg 48, xl 56.
- **Social icons** are filled/colored brand glyphs (FB blue, Google multi, etc.) — not the line set.
- **Payment icons** (Visa, MC, Amex, etc.) are full-color SVGs with their official marks.

### Emoji
**Not used.** The visual system relies on the icon library. Emoji are explicitly avoided in product surfaces.

### Unicode
- `·` (middle dot) for separators in breadcrumbs and metadata lines.
- `×` (multiplication) for close buttons when a proper X icon isn't available.
- Arrows (`→`) appear as line icons, not Unicode.

---

## Caveats

1. **Logo is a placeholder.** The codebase ships Untitled UI's generic rounded-square + purple-disc logo in `foundations/logo/untitledui-logo.tsx`. Planet DDS presumably has its own wordmark. The preview cards and UI kits use a simple "Planet DDS" wordmark with a blue square mark as a stand-in. **⚠️ Please provide the real logo (SVG preferred).**
2. **Fonts are loaded via Google Fonts.** The codebase declares `"Inter"` as the family but doesn't bundle font files. We pull Inter (and JetBrains Mono for code) from Google Fonts CDN. If Planet DDS has licensed variable/brand-tuned fonts, swap the `@import` in `colors_and_type.css`.
3. **Icon set substitution.** `@untitledui/icons` isn't CDN-available in the scale we need; mockups use Lucide from CDN. Visually near-identical, but exact glyphs differ.
4. **Product screenshots & photography.** None were shipped with the package. The UI kits use placeholder gray blocks where product photography would go.
5. **Dark mode.** The theme.css scaffolds dark-mode variables but the codebase left them mostly empty. This design system ships **light mode only** for now.
6. **No marketing-specific brand colors.** The marketing components in `@planetdds/ui` use the same brand blue as the app — so marketing and app feel continuous.

---

## How to use this system

1. Link `colors_and_type.css` at the top of any HTML mockup to get the full token set.
2. Copy components from `ui_kits/artemis` or `ui_kits/marketing` as JSX snippets.
3. For slides, lift the brand colors and use the `PlanetDDSLogo` wordmark from `assets/`.
4. See `SKILL.md` for agent-driven design workflows.
